package com.he.control;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.SecondaryLoop;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.imageio.ImageIO;

public class IsControl {
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	Object event;
	private Robot robot;
	public IsControl(ObjectOutputStream oos,ObjectInputStream ois) {
		this.oos=oos;
		this.ois=ois;
		Boolean b=null;
		try {
			robot = new Robot();
			b=ois.readBoolean();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
		if(b){
			getEvent();
			new Thread(){
				public void run() {
					putImage();
				};
			}.start();

		}
		
	}
	//���տ���
	public void getEvent(){
		try {
			
			while(true){
				event=ois.readObject();
				//�ж�������¼����Ǽ����¼�
				if (event instanceof MouseAdapter){
					MouseEvent mouse=(MouseEvent)event;
					int id=mouse.getID();
					//�ж��������һ�ֲ���
					if (id==MouseEvent.MOUSE_PRESSED){
						//�жϰ�ʲô��
						switch (id) {
					    	case MouseEvent.BUTTON1:
							robot.mousePress(InputEvent.BUTTON1_MASK);
							break;
						case MouseEvent.BUTTON2:
							robot.mousePress(InputEvent.BUTTON2_MASK);
							break;	
						case MouseEvent.BUTTON3:
							robot.mousePress(InputEvent.BUTTON3_MASK);
							break;
						default:
							break;
						}
						
					}
					//�ͷ����
					else if(id==MouseEvent.MOUSE_RELEASED){
						switch (id) {
						case MouseEvent.BUTTON1:
							robot.mouseRelease(InputEvent.BUTTON1_MASK);
							break;
						case MouseEvent.BUTTON2:
							robot.mouseRelease(InputEvent.BUTTON2_MASK);
							break;	
						case MouseEvent.BUTTON3:
							robot.mouseRelease(InputEvent.BUTTON3_MASK);
							break;
						default:
							break;
						}
					}
					//����ƶ�
					else if(id==MouseEvent.MOUSE_MOVED){
						robot.mouseMove(mouse.getX(), mouse.getY());
					}
					//����϶�
					else if(id==MouseEvent.MOUSE_DRAGGED){
						robot.mousePress(InputEvent.BUTTON1_MASK);
						robot.mouseMove(mouse.getX(), mouse.getY());
					}
					//�����ƶ�
					else if(id==MouseEvent.MOUSE_WHEEL){
						robot.mouseWheel((int) InputEvent.MOUSE_WHEEL_EVENT_MASK);
					}
				}else if(event instanceof KeyAdapter){
					KeyEvent key=(KeyEvent)event;
					int id=key.getID();
					//���°�ť
					if(id==KeyEvent.KEY_PRESSED){
						robot.keyPress(key.getKeyCode());
					}
					//�ͷŰ�ť
					else if (id==KeyEvent.KEY_RELEASED){
						robot.keyRelease(key.getKeyCode());
					}
				}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//����ͼƬ
	public void putImage(){
		Dimension di=Toolkit.getDefaultToolkit().getScreenSize();
		Rectangle re=new Rectangle(new Point(0,0), di);
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		while(true){
			BufferedImage bi=robot.createScreenCapture(re);
			System.out.println("+++++++++++++����ͼƬ+++++++++++++");
			try {
				ImageIO.write(bi, "jpeg", baos);
				byte[] Byte=baos.toByteArray();
				//�����ֽ���
				oos.writeInt(Byte.length);
				//�����ֽ�
				oos.write(Byte);
				oos.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//ͣ��200����
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
