package com.he.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * ��Ŀ��ʼ
 * @author 24324
 *
 */
public class Start extends JFrame{
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private static Start start;


	public static void main(String[] args) {
		start = new Start();
		start.createConn();
		start.init();
		start.addFun();
	}
	private void addFun() {
		this.setLayout(null);
		JLabel jl=new JLabel("��ѡ��");
		jl.setBounds(100,100,50,50);
		JButton con=new JButton("����");
		con.setBounds(100,150,100,100);
		JButton isCon=new JButton("������");
		isCon.setBounds(200,150,100,100);
		add(jl);
		add(con);
		add(isCon);
		setVisible(true);
		
		ActionListener al=new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String cho=e.getActionCommand();
				if("����".equals(cho)){
					//����Ϊ���ƶ������0
					try {
						oos.writeInt(0);
						//����Ҫ��flush
						oos.flush();
						System.out.println("����0");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					start.dispose();
					new Control(oos, ois);
				}
				if("������".equals(cho)){
					//�����ƶ����1
					try {
						oos.writeInt(1);
						oos.flush();
						System.out.println("����1");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					start.dispose();
							new IsControl(oos, ois);
				}
			}
		};
		con.addActionListener(al);
		isCon.addActionListener(al);
	}


	private void init() {
		// ���ñ���
		setTitle("Զ�̿���");
		// ���ô���λ��
		setLocation(250, 200);
//		setLocationRelativeTo(null);
		// ���ô��ڴ�С
		setSize(400, 300);
		// ���ùرմ��ڼ��رճ���
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		// ���ò��ܸı䴰�ڴ�С
		setResizable(false);
		
	}


	private void createConn() {
		try {
			Socket socket = new Socket("localhost", 9090);
			oos = new ObjectOutputStream(socket.getOutputStream());
			ois = new ObjectInputStream(socket.getInputStream());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
