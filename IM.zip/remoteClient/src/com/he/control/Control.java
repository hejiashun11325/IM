package com.he.control;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * �������Ӻʹ�������
 * 
 * @author 24324
 *
 */
public class Control extends JFrame {
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private JLabel jl;
	public Control(ObjectOutputStream oos,ObjectInputStream ois) {
		this.oos=oos;
		this.ois=ois;
		init();
		Boolean b = null;
		try {
			b = ois.readBoolean();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(b);
		if(b){
			sendMouseEvent();
			sendKeyEvent();
			new Thread(){
				public void run() {
					getImage();
				};
			}.start();
		}
	}

	

	public void init() {
		// ���ñ���
		setTitle("Զ�̿���");
		// ���ô���λ��
		setLocation(0,0);
//		 setLocationRelativeTo(null);
		// ���ô��ڴ�С
		Dimension di=Toolkit.getDefaultToolkit().getScreenSize();
		
		setSize(di);
		// ���ùرմ��ڼ��رճ���
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		// ���ò��ܸı䴰�ڴ�С
		setResizable(false);
		jl = new JLabel();
		add(jl);
		setVisible(true);
		
	}
	//��������¼�
	public void sendMouseEvent(){
		MouseAdapter ma=new MouseAdapter() {
			//�������
			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				super.mousePressed(arg0);
				try {
					oos.writeObject(arg0);
					oos.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//�ɿ����
			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				super.mouseReleased(arg0);
				try {
					oos.writeObject(arg0);
					oos.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//����϶�
			@Override
			public void mouseDragged(MouseEvent arg0) {
				// TODO Auto-generated method stub
				super.mouseDragged(arg0);
				try {
					oos.writeObject(arg0);
					oos.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//����ƶ�
			@Override
			public void mouseMoved(MouseEvent arg0) {
				// TODO Auto-generated method stub
				super.mouseMoved(arg0);
				try {
					oos.writeObject(arg0);
					oos.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			//������
			@Override
			public void mouseWheelMoved(MouseWheelEvent arg0) {
				// TODO Auto-generated method stub
				super.mouseWheelMoved(arg0);
				try {
					oos.writeObject(arg0);
					oos.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		addMouseListener(ma);
	}
	//��ȡ�������Ƭ
	public void getImage(){
		int length;
		try {
			length = ois.readInt();
			System.out.println(length);
			byte[] Byte=new byte[length];
			ois.readFully(Byte);
			ImageIcon ii=new ImageIcon(Byte);
			jl.setIcon(ii);
			jl.repaint();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//���ͼ����¼�
	public void sendKeyEvent(){
		KeyAdapter ka=new KeyAdapter() {
			//���̰���
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				super.keyPressed(e);
				try {
					oos.writeObject(e);
					oos.flush();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			//�����ɿ�
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				super.keyReleased(e);
				try {
					oos.writeObject(e);
					oos.flush();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		};
		this.addKeyListener(ka);
	}
}
