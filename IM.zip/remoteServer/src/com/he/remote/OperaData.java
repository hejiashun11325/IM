package com.he.remote;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class OperaData {
	/**
	 * 1�ǿ��ƶˣ�2�Ǳ����ƶ�
	 */
	ObjectOutputStream oos1;
	ObjectInputStream ois1;
	ObjectOutputStream oos2;
	ObjectInputStream ois2;
	public OperaData(ObjectOutputStream oos1,ObjectInputStream ois1,ObjectOutputStream oos2,ObjectInputStream ois2) {
		this.oos1=oos1;
		this.ois1=ois1;
		this.oos2=oos2;
		this.ois2=ois2;
		repeat();
	}
	//ת������
	private void repeat() {
		while(true){
			try {
				Object obj=ois1.readObject();
				oos2.writeObject(obj);
				oos2.flush();
			} catch (ClassNotFoundException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
	
}
