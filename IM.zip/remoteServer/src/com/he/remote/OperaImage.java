package com.he.remote;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class OperaImage extends Thread{
	/**
	 * 1�ǿ��ƶˣ�2�Ǳ����ƶ�
	 */
	ObjectOutputStream oos1;
	ObjectInputStream ois1;
	ObjectOutputStream oos2;
	ObjectInputStream ois2;
	public OperaImage(ObjectOutputStream oos1,ObjectInputStream ois1,ObjectOutputStream oos2,ObjectInputStream ois2) {
		this.oos1=oos1;
		this.ois1=ois1;
		this.oos2=oos2;
		this.ois2=ois2;
		
	}
	@Override
	public void run() {
		super.run();
		while(true){
			try {
				int length=ois2.readInt();
				byte[] Byte=new byte[length];
				ois1.read(Byte);
				oos1.writeInt(length);
				oos1.write(Byte);
				oos1.flush();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
